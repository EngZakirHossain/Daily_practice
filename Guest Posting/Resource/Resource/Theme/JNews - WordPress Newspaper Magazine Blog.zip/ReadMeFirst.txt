Welcome To JNews
 - You will need to upload jnews-theme.zip as your theme.
 - Please install necessary plugin first
 - Go to WordPress admin panel > JNews > Import Demo & Style to replicate our demo.
 - For more information, please read documentation or watch video documentation, you can also find documentation online at : http://support.jegtheme.com/theme/jnews/ for more update documentation
 - If you find any problem during installation or setting up theme, please go to http://support.jegtheme.com
 - If you going to make heavy change on themes, you can use JNews child. But if you going to make simple css change, please use additional css feature on Customizer